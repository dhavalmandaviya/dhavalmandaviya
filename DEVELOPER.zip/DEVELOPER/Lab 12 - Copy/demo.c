#include <stdio.h>
int main() {
	int a,b,c,d,e,total,pr;
	printf("Enter the five subject marks: \n");
	scanf("%d %d %d %d %d", &a,&b,&c,&d,&e);
	total = a+b+c+d+e;
	pr = (total/500)*100;
	if(pr>=61 && pr<=70) {
		printf("You are Pass ! and Your class is A!");
	}
	else if(pr>=46 && pr<=60) {
		printf("You are Pass ! and Your class is B!");
	}
	else if(pr>=36 && pr<=45) {
		printf("You are Pass !");
	}
	else if(pr<=35) {
		printf("You are Fail !");
	}
	else {
		printf("error");
	}
	return 0;
}
