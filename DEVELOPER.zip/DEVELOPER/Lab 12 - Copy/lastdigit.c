#include <stdio.h>
int main() {
	int a,b;
	printf("Enter a Number: \n");
	scanf("%d", &a);
	b = a%10;
	if(b%2==0) {
		printf("The last digit is Even!");
	}
	else if(a>=0 && a<=9) {
		if(a%2==0) {
			printf("The one digit is Even");
		}
		else {
			printf("The one digit is Odd");	
		}
	}
	else {
		printf("The last digit is Odd!");
	}
	return 0;
}
