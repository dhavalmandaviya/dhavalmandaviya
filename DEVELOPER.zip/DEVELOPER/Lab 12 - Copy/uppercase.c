#include <stdio.h>
int main() {
	char n;
	printf("Enter the character to ckeck it: \n");
	scanf("%c", &n);
	if(n>='A' && n<='Z') {
		printf("The character is upper case!");
	}
	else if(n>='a' && n<='z') {
		printf("The character is lower case!");
	}
	else if(n>='0' && n<='9') {
		printf("The character is Digit!");
	}
	else {
		printf("The character is special character");
	}
	return 0;
}
