#include <stdio.h>
int main() {
	int salary,hra,da;
	printf("Enter the Basic salary: \n");
	scanf("%d", &salary);
	if(salary>=30000) {
		hra = salary*0.30;
		da = salary*0.95;
		printf("Total Gross Salary = %d", salary+hra+da);
	}
	else if(salary>=20000) {
		hra = salary*0.25;
		da = salary*0.90;
		printf("Total Gross Salary = %d", salary+hra+da);
	}
	else if(salary>=10000) {
		hra = salary*0.20;
		da = salary*0.80;
		printf("Total Gross Salary = %d", salary+hra+da);
	}
	else {
		hra=0;
		da=0;
		printf("Wrong value!");
	}
	return 0;
}
