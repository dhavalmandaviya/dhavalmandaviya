#include <stdio.h>
int main() {
	char c;
	int a,b;
	printf("What do you want to (+,-,*,/): \n");
	scanf("%c", &c);
	
	printf("Enter a two value:\n");
	scanf("%d %d", &a,&b);
	
	if(c=='+') {
		printf("a + b = %d", a+b);
	}
	else if(c=='-') {
		printf("a - b = %d", a-b);
	}
	else if(c=='*') {
		printf("a * b = %d", a*b);
	}
	else if(c=='/') {
		printf("a / b = %d", a/b);
	}
	else {
		printf("Value is wrong!");
	}
	return 0;
}
