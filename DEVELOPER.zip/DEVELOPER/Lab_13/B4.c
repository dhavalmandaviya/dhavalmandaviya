/*
B4  Determine the roots of the equation ax2+bx+c=0.
*/

#include <stdio.h>
#include <math.h>
int main() {
	float a,b,c,d,root1,root2,realpart,imgpart;
	printf("Enter the three value: ");
	scanf("%f %f %f", &a,&b,&c);
	
	d=b*b-4*a*c;
	if(d>0) {
		root1 =-b + sqrt(d)/(2*a);
		root2 =-b - sqrt(d)/(2*a);
		printf("The roots are real and distinct = %f and %f", root1,root2);
	}
	else if(d==0) {
		root1 = root2 =-b/(2*a);
		printf("The roots are real and equal = %f and %f", root1,root2);
	}
	else {
		realpart =-b/(2*a);
		imgpart = sqrt(-d)/(2*a);
		printf("The roots are complex = %f + %f and %f + %f", realpart, imgpart, realpart, imgpart);
	}
	return 0;
}
