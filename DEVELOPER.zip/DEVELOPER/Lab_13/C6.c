/*
C6 Find the second largest number among three user input numbers.
*/

#include <stdio.h>
void main() {
	int a,b,c;
	printf("Enter the three value:\n");
	scanf("%d %d %d", &a,&b,&c);
	if((a>b && a<c) || (a>c && a<b)) {
		printf("A is 2nd largest number");
	}
	else if((b>a && b<c) || (b>c && b<a)) {
		printf("B is 2nd largest number");
	}
	else {
		printf("C is 2nd largest number");
	}
}
