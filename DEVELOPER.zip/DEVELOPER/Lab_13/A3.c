/*
 3. Input electricity unit charge and calculate the total electricity bill according to the given condition: (A)  
? For first 50 units Rs. 0.50/unit 
? For next 100 units Rs. 0.75/unit 
? For next 100 units Rs. 1.20/unit 
? For unit above 250 Rs. 1.50/unit 
 An additional surcharge of 20% is added to the bill. 
*/

#include <stdio.h>
void main() {
	float unit,ammount,total;
	printf("Enter the Unit: \n");
	scanf("%f", &unit);
	if(unit<=50) {
		ammount=unit*0.50;
	}
	else if(unit<=150) {
		ammount = (unit*0.50) + (unit-50)*0.75;
	}
	else if(unit<=250) {
		ammount = (unit*0.50) + (unit*0.75) + (unit-150)*1.20;
	}
	else {
		ammount = (unit*0.50) + (unit*0.75) + (unit*1.20) + (unit-250)*1.5;
	}
	total = ammount*0.20;
	printf("Total bill = %.3f", total);
}
