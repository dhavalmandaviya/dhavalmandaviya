/*
B5. Three sides of a triangle are entered through the keyboard, WAP to check whether the triangle is isosceles, equilateral,  
scalene or right-angled triangle.
*/

#include <stdio.h>
void main() {
	int a,b,c;
	printf("Enter the three angle of triangle : \n");
	scanf("%d %d %d", &a,&b,&c);
	if(a+b>c && b+c>a && a+c>b) {
		if(a==b && b==c) {
			printf("The Tringle is equilateral\n");
		}
		else if(a==b || b==c || a==c) {
			printf("The Tringle is isosceles\n");
		}
		else {
			printf("The Tringle is scalene\n");
		}
		if((a*a == b*b+c*c) || (b*b==a*a+c*c) (c*c==a*a+b*b)) {
			printf("The tringle is right-angled triangle");
		}
	}	
	else {
		printf("This is not a Tringle. \n");
	}
}
