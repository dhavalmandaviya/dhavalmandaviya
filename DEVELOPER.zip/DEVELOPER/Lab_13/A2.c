#include <stdio.h>
void main() {
	int a;
	printf("Enter a day number: \n");
	scanf("%d", &a);
	if(a==1) {
		printf("January");
	}
	else if(a==2) {
		printf("February");
	}
	else if(a==3) {
		printf("March");
	}
	else if(a==4) {
		printf("April");
	}
	else if(a==5) {
		printf("May");
	}
	else if(a==6) {
		printf("June");
	}
	else if(a==7) {
		printf("July");
	}
	else if(a==7) {
		printf("August");
	}
	else if(a==7) {
		printf("September");
	}
	else if(a==7) {
		printf("October");
	}
	else if(a==7) {
		printf("November");
	}
	else if(a==7) {
		printf("December");
	}
	else {
		printf("Invalid Month number!");
	}
}
