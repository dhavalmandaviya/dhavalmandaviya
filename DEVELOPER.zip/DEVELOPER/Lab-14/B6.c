#include <stdio.h>
int main() 
{
	char ch,a;
	printf("Enter a character: ");
	scanf("%c", &ch);
	
	a = (ch>='A' || ch>='a' && ch<='Z' || ch>='z')?printf("This is a Alpghabet") : printf("This is not Alphabet");
	
	return 0;
}

