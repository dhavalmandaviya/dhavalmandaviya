#include <stdio.h>
int main() 
{
	int a,b,c,large;
	printf("Enter a three value");
	scanf("%d %d %d", &a,&b,&c);
	
	switch(a>b) 
	{
		case 1:
			large=a;
			break;
		case 0:
			large=b;
			break;
		default:
			printf("Wrong!");
	}
	printf("Multiply with third number = %d", large*c);
	return 0;
}

