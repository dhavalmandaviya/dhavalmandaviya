#include <stdio.h>
int main() 
{
	int a,year;
	printf("Enter a month number ");
	scanf("%d", &a);
	
	switch(a)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			printf("The month have 31 days");
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			printf("The month have 30 days");
			break;
		case 2:
			printf("Enter a year ");
			scanf("%d", &year);
			if((year%400==0) || (year%4==0 && year%100!=0)) {
				printf("This is a Leap year \nand Month have 29 days");
			}
			else {
				printf("This is not Leap year \nand Month have 28 days");
			}
			break;
		default:
			printf("Wrong");
	}
	return 0;
}
