#include <stdio.h>
int main() 
{
	int a,b;
	char op;
	
	printf("What do you want to perform: (+,-,*,/)");
	scanf("%c", &op);
	
	printf("Enter a two number: \n");
	scanf("%d %d", &a,&b);
	
	switch(op) 
	{
		case '+':
			printf("a + b = %d", a+b);
		break;
		case '-':
			printf("a - b = %d", a-b);
		break;
		case '*':
			printf("a * b = %d", a*b);
		break;
		case '/':
			printf("a / b = %d", a/b);
		break;
		default:
			printf("Wrong value");
	}
	return 0;
}

