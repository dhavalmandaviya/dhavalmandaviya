/*
Lab-17
2. Get 10 numbers from user print count of odd, even numbers.
*/
#include <stdio.h>
int main()
{
	int i=1,a,count1=0,count2=0;
	printf("Enter a : ");
	while(i<=10) {
		scanf("%d",&a);
		if(a%2==0) {
			count1++;
		}
		else if(a%2!=0) {
			count2++;
		}
		i++;
	}
	printf("Odd no.=%d  Even =%d", count2, count1);
	return 0;
}
