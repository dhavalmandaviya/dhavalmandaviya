/*
Lab-17
 1. Print sum of 1 to n numbers.
*/
#include <stdio.h>
int main()
{
	int i=1,n,sum=0;
	printf("Enter n : \n");
	scanf("%d",&n);
	while(i<=n) {
		sum = sum + i;
		i++;
	}
	printf("Total sum = %d", sum);
	return 0;
}
