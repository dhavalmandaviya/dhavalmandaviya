/*
 4. Print multiplication table of a given number.
*/
#include <stdio.h>
int main()
{
	int i=1,n,table;
	printf("Enter a value to get the table :");
	scanf("%d", &n);
	while(i<=10) 
	{
		table=n*i;
		printf("%d * %d = %d \n", n,i,table);
		i++;
	}
	return 0;
}
