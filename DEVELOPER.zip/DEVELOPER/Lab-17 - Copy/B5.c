/*
 5. Print first 50 numbers in series 1, 4, 7,10.. 
*/
#include <stdio.h>
int main()
{
	int i=1,count=1;
	while(count<=50) 
	{
		printf("%d \n", i);
		i=i+3;
		count++;
	}

	return 0;
}
