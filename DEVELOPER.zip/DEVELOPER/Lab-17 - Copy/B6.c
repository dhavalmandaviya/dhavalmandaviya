/*
6. Print sum of series 1 + 4 + 9 + 16 + 25 + 36 + n.
*/
#include <stdio.h>
int main()
{
	int i=1,n,sum=0;
	printf("Enter n :");
	scanf("%d", &n);
	while(i<=n)
	{
		sum=sum+(i*i);
		i++;
	}
	printf("%d", sum);
	return 0;
}
