/*
5. Print the upper triangular matrix.
*/
#include <stdio.h>
void main() {
	int a[50][50],n,i,j;
	
	printf("Enter sqaure matrix number:\n");
	scanf("%d",&n);
		
	printf("\nEnter matrix elements:\n");
	
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	
	printf("\nMatrix: \n");
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			if(j > i) {
				printf("%d ",a[i][j]);
			}
			else {
				printf("0 ");	
			}
		}
		printf("\n");
	}
}
