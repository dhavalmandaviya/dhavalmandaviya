//Input a string in character array and print string and length of string.
#include<stdio.h>
void main()
{
	int i;
	char str[64];
	printf("Enter string : ");
	gets(str);
	puts(str);
	for(i=0;str[i]!='\0';i++)
	{
		printf("%c \n",str[i]);
	}
	printf(" length : %d",i);
}
