/*
3. Read a matrix and print diagonal elements and its sum.
*/
#include <stdio.h>
void main() {
	int a[50][50],n,i,j,sum=0;
	
	printf("Enter sqaure matrix number:\n");
	scanf("%d",&n);
	
	printf("\nEnter matrix elements:\n");
	
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	
	printf("\nMatrix: \n");
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	printf("\n");
	
	for(i=0;i<n;i++) {
		printf("%d ",a[i][i]);
		sum = sum + a[i][i];
	}
	
	printf("\nFinal Result: \n");
	printf("%d",sum);

}
