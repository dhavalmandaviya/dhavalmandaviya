/*
4. Check a given matrix is a sparse matrix or not.
*/
#include <stdio.h>
void main() {
	int a[50][50],n,i,j,zero=0,nonzero=0;
	
	printf("Enter sqaure matrix number:\n");
	scanf("%d",&n);
	
	printf("\nEnter matrix elements:\n");
	
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	
	printf("\nMatrix: \n");
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	printf("\n");
	
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			if(a[i][j] == 0) {
				zero++;
			}
			else {
				nonzero++;
			}
		}
	}
	
	printf("\nFinal Result: \n");
	
	if(zero > nonzero) {
		printf("Matrix is sparse!");
	}
	else {
		printf("Matrix is not sparse!");
	}

}
