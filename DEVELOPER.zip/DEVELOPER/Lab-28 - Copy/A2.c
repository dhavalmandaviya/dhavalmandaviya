/*
2. Check given two matrices are identical or not.
*/
#include <stdio.h>
void main() {
	int a[50][50],b[50][50],r,c,i,j,ide=1;
	
	printf("Enter rows and columns:\n");
	scanf("%d %d",&r,&c);
	
	printf("\nEnter 1st matrix elements:\n");
	
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	
	printf("\nEnter 2nd matrix elements:\n");
	
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			scanf("%d",&b[i][j]);
		}
	}
	
	printf("\n1st Matrix: \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	printf("\n2nd Matrix: \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			if(a[i][j] != b[i][j]) {
				ide=0;
			}
		}
	}
	
	printf("\nFinal Result: \n");
	if(ide==1) {
		printf("Matrix is identical !");
	}
	else {
		printf("Matrix is not identical !");
	}
}
