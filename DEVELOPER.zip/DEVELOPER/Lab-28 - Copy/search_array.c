//Search element in array.
#include<stdio.h>
void main ()
{
	int n,i,s;
	printf("Enter n : ");
	scanf("%d",&n);
	int array[n];
	printf("Enter Array : ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&array[i]);
	}
	printf("\n \n Search Key : ");
	scanf("%d",&s);
	for(i=0;i<n;i++)
	{
		array[i]==s?n=i-1:printf("");
	}
	i!=n?printf("%d found at %d",s,i):printf("%d not found",s);
}
