// Swap first element with last, second to second last and so on.
#include<stdio.h>
void main()
{
	int n,i,j;
	printf("enter n : ");
	scanf("%d",&n);
	int a[n];
	j=n-1;
	printf("Enter array elements : \n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n/2;i++)
	{
		a[i]+=a[j];
		a[j]=a[i]-a[j];
		a[i]-=a[j];
		j--;
	}
	printf("After swaping array : \n");
	for(i=0;i<n;i++)
	{
		printf("%d \n",a[i]);
	}
}
