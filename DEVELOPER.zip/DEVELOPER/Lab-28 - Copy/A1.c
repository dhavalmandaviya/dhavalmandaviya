/*
1. Count number of odd and even elements from N X N matrix.
*/
#include <stdio.h>
void main() {
	int a[50][50],r,c,i,j,even=0,odd=0;
	
	printf("Enter rows and columns:\n");
	scanf("%d %d",&r,&c);
	
	printf("\nEnter elements:\n");
	
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	
	printf("\nMatrix: \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			if(a[i][j] % 2 == 0) {
				even++;
			}
			else {
				odd++;
			}
		}
	}
	
	printf("\nTotal Even elements in matrix: %d \n",even);
	printf("Total Odd elements in matrix: %d",odd);
}
