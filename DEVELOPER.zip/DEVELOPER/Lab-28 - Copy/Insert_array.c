// Swap first element with last, second to second last and so on.
#include<stdio.h>
void main()
{
	int n=0,i=0,e=0,x=0;
	printf("enter n : ");
	scanf("%d",&n);
	int a[n+1];
	printf("Enter array elements : \n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter inserting element : ");
	scanf("%d",&e);
	printf("enter index value : ");
	scanf("%d",&x);
	for(i=n+1;i>x-1;i--)
	{
		a[i]=a[i-1];
	}
	a[x-1]=e;
	printf("After inserting array : \n");
	for(i=0;i<n+1;i++)
	{
		printf("%d \n",a[i]);
	}
}
