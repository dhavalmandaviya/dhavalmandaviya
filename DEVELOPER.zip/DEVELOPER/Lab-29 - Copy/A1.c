/*
1. Use string handling functions strlen(), strcmp(), strcpy(), strcat(), strrev(), strlwr() and strupr()
*/
#include <stdio.h>
#include <string.h>
void main()
{
	char str[100]="Hello",str1[100]="World",str2[100]="Pro";
	int i;
	
	// strlen()
	printf("Lenght of Hello:- %d \n",strlen(str));
	printf("\n");
	
	//strcmp()
	printf("Hello and World ");
	if(strcmp(str1,str)==0) {
		printf("String are same! \n");
	}
	else {
		printf("String are not same! \n");
	}
	printf("\n");
	
	//strcpy()
	printf("Copy string:- \n ");
	strcpy(str,str1);
	printf("%s \n",str);
	printf("\n");
	
	//strcat
	printf("Merged string:-\n");
	strcat(str,str1);
	printf("%s \n",str);
	printf("\n");
	
	//strrev()
	printf("Reverse string:- \n ");
	strrev(str2);
	printf("%s \n",str2);
	printf("\n");
	
	//strlwr()
	printf("Lowercase string:- \n");
	strlwr(str);
	printf("%s \n",str);
	printf("\n");
	
	//strlupr()
	printf("Upercase string:-\n");
	strupr(str2);
	printf("%s \n",str2);
	printf("\n");
}
