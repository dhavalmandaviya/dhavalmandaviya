/*
3. Find a character from given string. 
*/
#include <stdio.h>
void main() {
	char str[100], ch;
	int i,flag=0;
	
	printf("Enter string:\n");
	gets(str);
		
	printf("Enter character to find if availabel or not:");
	scanf("%c",&ch);
	
	for(i=0;str[i]!='\0';i++) {
		if(str[i]==ch) {
			flag=1;
			break;
		}
	}
	if(flag==1) {
		printf("Found!");
	}
	else {
		printf("Not Found!");
	}
}
