/*
2. Print all character of given string.
*/
#include <stdio.h>
void main() {
	char str[100];
	int i;
	
	printf("Enter string:\n");
	gets(str);
	
	for(i=0;str[i]!='\0';i++) {
		printf("%c\n",str[i]);
	}
}
