/*
4. Replace a character in given string.
*/
#include <stdio.h>
void main()
{
	char str[100], old1,new1;
	int i;
	
	printf("Enter string: \n");
	scanf("%s",str);
	
	fflush(stdin);
	printf("Which char would you replace?\n");
	scanf("%c",&old1);
	
	fflush(stdin);
	printf("Which new char would you replace?\n");
	scanf("%c",&new1);
	
	for(i=0;str[i]!='\0';i++) {
		if(str[i]==old1) {
			str[i]=new1;
		}
	}
	printf("Updated string = %s",str);
}
