/*
2. Print sum of 1 to n numbers. 
*/
#include <stdio.h>
void main() 
{
	int i,n,sum=0;
	
	printf("Enter n :\n");
	scanf("%d",&n);
	
	for(i=1;i<=n;i++) {
		printf("%d \n",i);
	}
	
	for (i=1;i<=n;i++) {
		sum=sum+i;
	}
	printf("Sum = %d \n",sum);
}

