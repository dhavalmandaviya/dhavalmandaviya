/*
9. Print all ASCII character with their values. 
*/
#include <stdio.h>
void main() 
{
	int i,n;
	for(i=1;i<127;i++) {
		printf("%d %c\n",i,i);
	}
}
