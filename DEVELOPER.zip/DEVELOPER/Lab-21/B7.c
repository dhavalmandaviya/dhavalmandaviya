/*
7. Print the Fibonacci Series.
*/
#include <stdio.h>
void main() 
{
	int i,n,sum,start=0,next=1;
	printf("Enter n :");
	scanf("%d",&n);
	
	for(i=1;i<=n;i++) {
		printf("%d ",start);
		sum = start + next;
		start = next;
		next=sum;
	}
}
