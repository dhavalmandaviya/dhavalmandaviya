/*
6. Print all factors of the given number.
*/
#include <stdio.h>
void main() 
{
	int i,n,fact=1;
	printf("Enter n :");
	scanf("%d",&n);
	
	for(i=1;i<=n;i++) {
		if(n%i==0) {
			printf("Factors = %d \n",i);
		}
	}
}
