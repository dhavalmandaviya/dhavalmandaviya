/*
4. Calculate x^y without using power function. 
*/
#include <stdio.h>
void main() 
{
	int i,result=1,x,y;
	printf("Enter X and Y :");
	scanf("%d %d",&x,&y);
	
	for(i=1;i<=y;i++) {
		result = result * x;
	}
	printf("Result = %d",result);
}
