/*
8. Count frequency of digits in an integer.
*/
#include <stdio.h>
void main() 
{
	int i,n,digit,a,b;
	printf("Enter n :");
	scanf("%d",&n);
	a = n;
	for(i=1;a!=0;i++) {
		b=n;
		digit = a % 10;
		int count = 0;
		for(;b!=0;) {
			int rem = b %10;
			if(rem == digit){
				count++;
			}
			b = b/10;
		}
		printf("%d -> %d\n", digit, count);
		a=a/10;
	}
}
