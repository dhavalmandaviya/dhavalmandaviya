/*
1. Print 1 to 10 then modify program print 1 to n. 
*/
#include <stdio.h>
void main() 
{
	int i,n;
	printf("1 to 10 number : \n");
	for(i=1;i<=10;i++) {
		printf("%d \n",i);
	}
	printf("\nEnter n \n");
	scanf("%d",&n);
	
	printf("\n1 to %d number :\n\n",n);
	for (i=1;i<=n;i++) {
		printf("%d \n",i);
	}
}
