/*
3. Print multiplication table of a given number. 
*/
#include <stdio.h>
void main() 
{
	int i,n,table;
	printf("Enter table number :\n");
	scanf("%d",&n);
	
	for(i=1;i<=10;i++) {
		table = n * i;
		printf("%d * %d = %d \n",n,i,table);
	}
}
