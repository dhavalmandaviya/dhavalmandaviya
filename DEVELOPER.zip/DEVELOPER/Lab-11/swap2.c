#include <stdio.h>
void main() {
	int a,b,temp;
	printf("Enter a Two value: \n");
	scanf("%d %d", &a,&b);
	printf("Your Value: a=%d and b=%d\n", a,b);
	a = a+b;
	b = a-b;
	a = a-b;
	printf("Swap Value a=%d and b=%d", a,b);
}
