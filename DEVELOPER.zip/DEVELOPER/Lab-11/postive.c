#include <stdio.h>
void main() {
	int a;
	printf("Enter a Two value: \n");
	scanf("%d", &a);
	if(a>0) {
		printf("The number is postive! \n");
	}
	else {
		printf("The number is negative! \n");
	}
}
