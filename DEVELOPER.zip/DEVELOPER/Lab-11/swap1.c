#include <stdio.h>
void main() {
	int a,b,temp;
	printf("Enter a Two value: \n");
	scanf("%d %d", &a,&b);
	printf("Your Value: a=%d and b=%d\n", a,b);
	temp = a;
	a = b;
	b = temp;
	printf("Swap Value a=%d and b=%d", a,b);
}
