#include <stdio.h>
void main() {
	int a,b,c;
	printf("Enter a three value: \n");
	scanf("%d %d %d", &a,&b,&c);
	if(a>b && a>c) {
		printf("A is largest number! \n");
	}
	else if(b>c) {
		printf("B is largest");
	}
	else {
		printf("C is largest!");
	}
}
