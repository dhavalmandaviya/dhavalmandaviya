#include <stdio.h>
void main() {
	char ch;
	printf("Enter the Alphabet=\n");
	scanf("%c", &ch);
	if(ch=='a' || ch=='A' || ch=='e' || ch=='E' || ch=='I' || ch=='i' || ch=='o' || ch=='O' || ch=='u' || ch=='U') {
		printf("The Alphabet is Vowel. \n");
	}
	else {
		printf("The Alphabet is Consonant.\n");
	}
}
