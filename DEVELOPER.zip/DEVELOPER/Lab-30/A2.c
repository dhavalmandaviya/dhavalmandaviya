/*
2. Convert a string into upper case and lower case string without using built-in function. 
*/
#include <stdio.h>
void main() {
	char str[100],upr[100],lwr[100];
	int i,len=0;
	
	printf("Enter string: \n");
	gets(str);

	
	for(i=0;str[i]!='\0';i++) {
		if(str[i] >= 'a' && str[i] <= 'z') {
			upr[i] = str[i] - 32;
		}
		else
		{
			upr[i] = str[i];
		}
		if(str[i] >= 'A' && str[i] <= 'Z') {
			lwr[i] = str[i] + 32;
		}
		else {
			lwr[i] = str[i];
		}
	}
	
	printf("Upper case = %s \n",upr);
	printf("Lower case = %s",lwr);
	
}
