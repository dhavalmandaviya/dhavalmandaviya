/*
4. Read two string from user and merge second string into first string without using built-in function.
*/
#include <stdio.h>
void main() {
	char str[100],str1[100];
	int i,j;
	
	printf("Enter 1st string: \n");
	gets(str);
	
	printf("Enter 2nd string: \n");
	gets(str1);
	
	for(i=0;str[i]!='\0';i++) {
	
	}
	for(j=0;str1[j]!='\0';j++) {
		str[i]=str1[j];
		i++;
	}
	
	str[i]='\0';
	
	printf("\n%s",str);

	
}
