/*
 1. Find length of given string without using built-in function.
*/
#include <stdio.h>
void main() {
	char str[100];
	int i,len=0;
	
	printf("Enter string: \n");
	gets(str);
	
	for(i=0;str[i]!='\0';i++) {
		len++;
	}
	printf("\nLength = %d",len);
}
