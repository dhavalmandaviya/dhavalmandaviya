/*
5. Count occurrence of a given character in a string. 
*/
#include <stdio.h>
void main() {
	char str[100],ch;
	int i,c=0;
	
	printf("Enter string: \n");
	gets(str);
	
	printf("Enter Character: \n");
	scanf("%c",&ch);
	
	for(i=0;str[i]!='\0';i++) {
		if(str[i]==ch) {
			c++;
		}
	}
	
	printf("\nTotal '%c' - charcter is %d",ch,c);

}
