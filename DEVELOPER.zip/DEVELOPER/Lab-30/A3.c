/*
3. Copy given string into another string without using built-in function.
*/
#include <stdio.h>
void main() {
	char str[100],str1[100];
	int i;
	
	printf("Enter string: \n");
	gets(str);
	
	for(i=0;str[i]!='\0';i++) {
		str1[i]=str[i];
	}
	
	printf("Copied string = %s \n",str1);
	
}
