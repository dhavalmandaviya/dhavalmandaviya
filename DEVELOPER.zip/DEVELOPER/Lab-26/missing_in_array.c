//Find missing numbers of sequence using array.
#include <stdio.h>
void main()
{
	int i,j,n;
	printf("enter n : ");
	scanf("%d",&n);
	double a[n],b[n];
	printf("enter array elements : \n");
	
	for(i=0;i<n;i++)
	{
		scanf(" %lf",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[j]!=a[i]+1)
			{
				b[i]=a[i];
				if(b[i]!=a[j]-1)
				{
					b[i]++;
				}
			}
		}
	}
	for(i=0;i<n;i++)
	{
		printf("missing elements : %lf \n",b[i]);
	}
}
