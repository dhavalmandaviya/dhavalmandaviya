//Sort elements of an array in an ascending order
#include <stdio.h>
void main()
{
	int i,j,n;
	printf("enter n : ");
	scanf("%d",&n);
	double a[n];
	printf("enter array elements : \n");
	
	for(i=0;i<n;i++)
	{
		scanf(" %lf",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[i]>a[j])
			{
				a[i]+=a[j];
				a[j]=a[i]-a[j];
				a[i]-=a[j];
			}
		}
	}
	printf("sorted array elements : \n");
	for(i=0;i<n;i++)
	{
		printf(" %lf \n",a[i]);
	}
}
