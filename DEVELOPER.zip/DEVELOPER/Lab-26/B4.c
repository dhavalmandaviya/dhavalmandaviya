/*
4. Swap first element with last, second to second last and so on.
*/
#include <stdio.h>
void main() {
	int a[100],n,i,j,temp;
	
	printf("Enter n: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	i=0;
	j=n-1;
	while(i < j) 
	{
		temp = a[i];
		a[i] = a[j];
		a[j] = temp;
		
		i++;
		j--;
	}
	for(i=0;i<n;i++) {
		printf("%d ",a[i]);
	}
	
}
