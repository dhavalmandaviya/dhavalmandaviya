/*
1. Search element in array. 
*/
#include <stdio.h>
void main() {
	int a[100],i,n,c=0,search;
	
	printf("Enter n: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	printf("Enter element to search: ");
	scanf("%d",&search);
	
	for(i=0;i<n;i++) {
		if(search == a[i]) {
			printf("Position = %d",i+1);
			c=1;
		}
	}
	if(c==0) {
		printf("Not Found");
	}
	
}
