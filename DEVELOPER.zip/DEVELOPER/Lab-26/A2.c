/*
2. Find maximum and minimum value from array. 
*/
#include <stdio.h>
void main() {
	int a[100],i,n,min=0,max=0;
	
	printf("Enter n: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	max = a[0];
	min = a[0];
	
	for(i=0;i<n;i++) {
		if(a[i] > max) {
			max=a[i];
		}
		if(a[i] < min) {
			min=a[i];
		}
	}
	printf("Max = %d",max);
	printf("Min = %d",min);
	
}
