/*
 3. Input a string in character array and print string and length of string.
*/
#include <stdio.h>
void main() {
	char str[100];
	int i;
	
	printf("Enter string: ");
	scanf("%s",&str[i]);
	
	while(str[i] != '\0') {
		i++;
	}
	
	printf("Your string is = %s \n",str);
	printf("Lenght = %d",i);
}
