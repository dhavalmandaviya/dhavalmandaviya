/*
5. Insert new value in the sorted array. 
*/

#include <stdio.h>

int main()
{
    int a[100], n, i, ele;

    printf("Enter size: ");
    scanf("%d", &n);

    printf("Enter elements: ");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    
    printf("Enter element: ");
    scanf("%d",&ele);
    
    

    return 0;
}
