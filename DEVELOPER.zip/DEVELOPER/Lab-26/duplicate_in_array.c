//Count total duplicate elements in an array. 
#include <stdio.h>
void main()
{
	int i,j,n,b=0;
	printf("enter n : ");
	scanf("%d",&n);
	double a[n];
	printf("enter array elements : \n");
	
	for(i=0;i<n;i++)
	{
		scanf(" %lf",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[i]==a[j])
			{
				b++;
				break;
			}
		}
	}
	printf("duplicate elements : %d",b);
}
