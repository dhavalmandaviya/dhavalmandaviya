/*
2. Count number of positive, negative and zero elements from 3 X 3 matrix. (
*/
#include <stdio.h>
void main() {
	int a[30] [30],i,j,pos=0,neg=0,zero=0;
	
	printf("Enter 3 * 3 matrix element: \n");
	for(i=0;i<3;i++) {
		for(j=0;j<3;j++) {
			scanf("%d",&a[i][j]);
			if(a[i][j] > 0) {
				pos++;
			}
			if(a[i][j] < 0) {
				neg++;
			}
			if(a[i][j] == 0) {
				zero++;
			}
		}
	}
	printf("Postive = %d \nNegetive = %d \nZero = %d",pos,neg,zero);
}
