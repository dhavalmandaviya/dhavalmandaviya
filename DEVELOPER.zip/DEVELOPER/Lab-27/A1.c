/*
1. Read values in two-dimensional array and print them in matrix form.
*/
#include <stdio.h>
void main() {
	int a[30] [30],i,j,r,c;
	
	printf("Enter row and column: ");
	scanf("%d %d", &r,&c);
	
	printf("Enter %d * %d matrix element: ",r,c);
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	
	printf("Your Matrix: \n");
		
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
}
