/*
Extra:- Two matrix addition
*/
#include <stdio.h>
void main() {
	int a[30] [30],b[30][30],c[30][30],i,j,r,c;
	
	printf("Enter rows and cols: \n");
	scanf("%d %d", &r,&c);
	
	printf("Enter A Matrix element: \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		scanf("%d",&a[i][j]);	
		}
	}
	printf("\n");
	
	printf("Enter B Matrix element: \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		scanf("%d",&b[i][j]);	
		}
	}
	
	printf("Your A Matrix");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		printf("%d ",a[j][i]);	
		}
		printf("\n");
	}
	
	printf("Your B Matrix");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		printf("%d ",b[j][i]);	
		}
		printf("\n");
	}

	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		c[i][j] = a[i][j] + b[i][j];	
		}
		printf("\n");
	}
	
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		printf("%d ",c[j][i]);	
		}
		printf("\n");
	}
}
