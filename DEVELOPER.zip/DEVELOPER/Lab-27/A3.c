/*
3. Read and store the roll no and marks of 20 students using 2D array. 
*/
#include <stdio.h>
void main() {
	int a[20] [2],i,j;
	
	printf("Enter 20 student roll no. and marks: \n");
	
	for(i=0;i<20;i++) {
		for(j=0;j<2;j++) {
		scanf("%d",&a[i][j]);	
		}
	}
	printf("Student details: \n");
	printf("Roll No.\tMarks\n");
	for(i=0;i<20;i++) {
		for(j=0;j<2;j++) {
		printf("%d\t",a[i][j]);	
		}
		printf("\n");
	}
}
