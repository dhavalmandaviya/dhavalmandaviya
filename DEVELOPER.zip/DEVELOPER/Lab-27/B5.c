/*
Extra:- Two matrix addition
*/
#include <stdio.h>
void main() {
	int a[30] [30], b[30] [30], co[30] [30],i,j,k,r1,c1,r2,c2;
	
	printf("Enter 1st matrix rows and cols: \n");
	scanf("%d %d", &r1,&c1);
	
	printf("Enter 2nd matrix rows and cols: \n");
	scanf("%d %d", &r2,&c2);
	
	while(c1!=r2) {
		printf("Matrix multiplication Not possible!");
	}
	
	printf("Enter A Matrix element: \n");
	for(i=0;i<r1;i++) {
		for(j=0;j<c1;j++) {
		scanf("%d",&a[i][j]);	
		}
	}
	printf("\n");
	
	printf("Enter B Matrix element: \n");
	for(i=0;i<r1;i++) {
		for(j=0;j<c1;j++) {
		scanf("%d",&b[i][j]);	
		}
	}
	

	for(i=0;i<r1;i++) {
		for(j=0;j<c2;j++) {
		co[i][j] = 0;	
		}
		for(k=0;k<c1;k++) {
			co[i][j] = co[i][j] + a[i][j] * b[i][j]
		}
	}
	
	printf("Your Multiplication Matrix \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		printf("%d ",co[i][j]);	
		}
		printf("\n");
	}
}
