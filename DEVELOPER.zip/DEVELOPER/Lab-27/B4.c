/*
4. Print Transpose of a matrix.
*/
#include <stdio.h>
void main() {
	int a[30] [30],i,j,r,c;
	
	printf("Enter rows and cols: \n");
	scanf("%d %d", &r,&c);
	
	printf("Enter Elements: \n");
	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		scanf("%d",&a[i][j]);	
		}
	}

	for(i=0;i<r;i++) {
		for(j=0;j<c;j++) {
		printf("%d ",a[j][i]);	
		}
		printf("\n");
	}
}
