/*
1 
0 1 
0 1 0 
1 0 1 0 
1 0 1 0 1
*/

#include <stdio.h>
void main() {
	int i,j,a=1;
	for(i=1;i<=5;i++) {
		for(j=1;j<=i;j++)
		 {
			printf("%d",a);
			if(a==0) {
				a=1;
			} 
			else {
				a=0;
			} 
		}
		printf("\n");
	}
}
