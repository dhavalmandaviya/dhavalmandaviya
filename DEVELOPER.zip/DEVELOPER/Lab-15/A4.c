#include<stdio.h>
int main()
{
	int a,b,c,value;
	printf("Enter a three number to find a largest value: ");
	scanf("%d %d %d", &a, &b, &c);
	value = (a>b)?((a>c)?printf("A is largest") : printf("C is largest")) : ((b>c)? printf("B is largest") : printf("C is largest"));
	
	return 0;
}
