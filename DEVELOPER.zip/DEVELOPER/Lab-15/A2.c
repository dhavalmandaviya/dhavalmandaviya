#include<stdio.h>
int main()
{
	int a,value;
	printf("Enter a number to check postive or negative: ");
	scanf("%d", &a);
	value=a>0?printf("Positive") : printf("Negative");
	
	return 0;
}
