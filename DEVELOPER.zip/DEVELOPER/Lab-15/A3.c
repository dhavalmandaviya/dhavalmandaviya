#include<stdio.h>
int main()
{
	int a,value;
	printf("Enter a number to check even or odd: ");
	scanf("%d", &a);
	value=a%2==0?printf("Even") : printf("Odd");
	
	return 0;
}
