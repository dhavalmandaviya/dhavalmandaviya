/*
 1. Find Max, Min, Sum, Avg. of given numbers from an array. 
*/
#include <stdio.h>
void main() {
	int i,n,a[100],max,min,sum=0;
	float avg;
	printf("Enter n \n");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	min = a[0];
	max = a[0];
	
	for(i=0;i<n;i++){
		if(a[i] < min) {
			min = a[i];
		}
		if(a[i] > max) {
			max = a[i];
		}
		sum+=a[i];
	}
	avg=sum/n;
	printf("Maximum = %d \nMinimum = %d\nSum = %d\n Avg = %f",max,min,sum,avg);
}
