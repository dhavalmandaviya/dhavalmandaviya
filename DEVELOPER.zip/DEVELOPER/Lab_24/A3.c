/*
3. Sort elements of an array in an ascending order.
*/
#include <stdio.h>
void main() {
	int i,j,n,a[100];
	float avg;
	printf("Enter n \n");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n-1;i++){
		for(j=i+1;j<n;j++) {
			int temp;
			if(a[j] < a[i]) {
				temp = a[j];
				a[j] = a[i];
				a[i] = temp;
			}
		}
	}
	printf("Ascending order: \n");
	
	for(i=0;i<n;i++) {
		printf("%d",a[i]);	
	}
	
}
