/*
2. Read five person height and weight and count the number of person having height greater than 170 and weight less than  
  50.
*/
#include <stdio.h>
void main() {
	int i,h[5],w[5],c=0;
	printf("Enter 5 value height \n");
	
	for(i=0;i<5;i++) {
		scanf("%d",&h[i]);
	}
	
	printf("Enter 5 value weight \n");
	
	for(i=0;i<5;i++) {
		scanf("%d",&w[i]);
	}


	for(i=0;i<5;i++) {
		if(h[i]>170 && w[i]<50) {
			c++;
		}
	}
	printf("Count = %d",c);
}
