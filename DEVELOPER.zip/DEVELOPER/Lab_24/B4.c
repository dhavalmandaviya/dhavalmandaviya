/*
4. Count total duplicate elements in an array.
*/
#include <stdio.h>
void main() {
	int i,j,n,a[100],c=1;
	printf("Enter n \n");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++) {
			if(a[i] == a[j]) {
			c++;
			break;
			}
		}
	}
	printf("Duplicate = %d",c);	
}
