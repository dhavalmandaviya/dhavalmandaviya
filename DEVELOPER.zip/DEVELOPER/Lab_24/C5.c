/*
 5. Find missing numbers of sequence using array.(in a sequence 1,2,4,5,7,8,10,  Missing numbers are 3,6,9)
*/
#include <stdio.h>
void main() {
	int i,j,n,a[100],c=1;
	printf("Enter n \n");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++){
		while(c<a[i]) {
			printf("%d ",c);
			c++;
		}
		c++;
	}	
}
