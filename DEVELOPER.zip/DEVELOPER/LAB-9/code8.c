#include<stdio.h>
int main(){
	int p;
	int roi;
	int time;
	printf("Enter a value of Principal, roi and time = \n");
	scanf("%d %d %d", &p, &roi, &time);
	printf("Simple interest value = %d", (p*roi*time/100));
	return 0;
}
