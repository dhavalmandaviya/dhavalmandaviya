#include<stdio.h>
int main(){
	int l,b;
	printf("Enter a value of L and B\n");
	scanf("%d %d", &l, &b);
	printf("Area of ractangle = %d", (l*b)/2);
	return 0;
}
