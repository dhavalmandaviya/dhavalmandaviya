#include<stdio.h>
int main(){
	float f;
	printf("Enter a value of Fahrenhiet = ");
	scanf("%f", &f);
	printf("Tempretaure from Fahrenhiet to celsius = %f", (((f-32)*5))/9);
	return 0;
}
