#include <stdio.h>
int main()
{
	char ch;
	printf("ASCII value Character");
	scanf("%c", &ch);
	printf("ASCII value Character=%d", ch);
	return 0;
}
