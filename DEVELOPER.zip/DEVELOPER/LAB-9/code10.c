#include<stdio.h>
int main(){
	int sec;
	printf("Enter a Second = ");
	scanf("%d", &sec);
	printf("%d:%d:%d", sec/3600, (sec%3600)/60, sec%60);
	return 0;
}
