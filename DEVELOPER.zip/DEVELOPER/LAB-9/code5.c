#include<stdio.h>

int main(){
	float a = 10.5;
	int b = (int)a;
	printf("Data loss = %f\n", a-b);
	printf("Int value of a= %d\n",b);
	return 0;
}
