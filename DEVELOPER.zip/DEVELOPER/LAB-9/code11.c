#include<stdio.h>
int main(){
	int total_days, years, weeks,day;
	printf("Enter a Days:\n");
	scanf("%d", &total_days);
	
	years = total_days/365;
	weeks = (total_days % 365) / 7;
	day = (total_days % 365) % 7;
	
	printf("Years: %d\nWeeks: %d\nDays: %d\n", years, weeks, day);
	return 0;
}
