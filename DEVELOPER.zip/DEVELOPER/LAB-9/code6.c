#include<stdio.h>

int main(){
char ch='C';

printf("%c", ch + 32);
}
