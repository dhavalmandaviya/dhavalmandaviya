/*
6. Calculate the square of integers 1 through 10. 
*/
#include <stdio.h>
#include <math.h>
int main()
{
	int i=1,sqaure;
	while(i<=10) {
		sqaure = i*i;
		printf("The square of %d = %d\n",i,sqaure);
		i++;
	}
}
