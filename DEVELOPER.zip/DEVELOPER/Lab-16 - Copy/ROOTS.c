#include <stdio.h>
#include <math.h>
void main ()
{
	float a,b,c,d,r1,r2;
	printf("enter a : ");
	scanf("%f",&a);
	printf("enter b : ");
	scanf("%f",&b);
	printf("enter c : ");
	scanf("%f",&c);
	
	d=sqrt((b*b)-(4*a*c));
	printf("d is : %f \n",d);	
	if(d<0) printf("roots are imagenary");
	r1=(-b)/(2*a);
	if(d==0) printf("one root only : %f",&r1);
	r1=((-b)+d)/2*a;
	r2=((-b)-d)/2*a;
	if(d>0) printf("two roots : %f , %f",r1,r2);
	
}
