#include<stdio.h>
int main()
{
	int a,b;
	printf("Enter a two number :");
	scanf("%d %d", &a,&b);
	int i=a;
	while(i<=b) 
	{
		if(i%2==0) {
			printf("%d \n", i);
		}
		i++;
	}
	return 0;
}
