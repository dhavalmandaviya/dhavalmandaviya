/*
4. Delete all duplicate elements from an array.
*/
#include <stdio.h>
void main() {
	int a[100],i,j,k,n,c=1;
	
	printf("Enter n:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++) {
		for(j=i+1;j<n;j++) {
			if(a[i]==a[j]) {
					c++;
			for(k=j;k<n-1;k++) {
				 a[k] = a[k+1];
			}
			n--;
			j--;
		}
		}
	}
	printf("\n");
	printf("Duplicate = %d \n",c);
	for(i=0;i<n;i++) {
		printf("%d ",a[i]);
	}
}
