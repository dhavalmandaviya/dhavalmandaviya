/*
3. Count number of elements divisible by 3 in array. 
*/
#include <stdio.h>
void main() {
	int a[100],i,n,c=0;
	
	printf("Enter n:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++) {
		if(a[i] % 3 ==0) {
			c++;
		}
	}
	printf("Count : \n");
	printf("%d",c);
}
