/*
1. Copy all elements of one array to another.
*/
#include <stdio.h>
void main() {
	int a[100],b[100],i,n;
	
	printf("Enter n:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++) {
		b[i]=a[i];
	}
	printf("Copy element : \n");
	for(i=0;i<n;i++) {
		printf("%d",b[i]);
	}
}
