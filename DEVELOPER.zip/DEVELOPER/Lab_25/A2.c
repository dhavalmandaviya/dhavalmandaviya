/*
2. Count total number of negative elements in array.
*/
#include <stdio.h>
void main() {
	int a[100],i,n,c=0;
	
	printf("Enter n:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	
	for(i=0;i<n;i++) {
		if(a[i] < 0) {
			c++;
		}
	}
	printf("Negative count : \n");
	printf("%d",c);
}
