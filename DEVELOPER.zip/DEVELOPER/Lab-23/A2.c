/*
2. Count number of positive or negative number from an array of n numbers.
*/
#include <stdio.h>
void main()
{
	int i,n,a[100],pos=0,neg=0;
	printf("Enter n element: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++) {
		if(a[i] > 0) {
			pos++;
		}
		else {
			neg++;
		}
	}
	
	printf("Positive: %d \nNegative: %d",pos,neg);
}
