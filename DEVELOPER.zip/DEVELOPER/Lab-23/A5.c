/*
5. Calculate the average, geometric and harmonic mean of n elements in an array. 
*/
#include <stdio.h>
#include <math.h>
int main()
{
	int n,i;
	printf("Enter n element: ");
	scanf("%d",&n);
	
	double a[n];
	double avg;
	double sum = 0.0;
	double pro = 1.0;
	double r_p = 0.0;
	double geo=0.0;
	double har=0.0;
	 
	for(i=0;i<n;i++) {
		scanf("%lf",&a[i]);
		sum+=a[i];
		pro*=a[i];
		r_p+=(1.0/a[i]);
	}
	geo=pow(pro,1.0/n);
	har=n/r_p;
	avg=sum/n;
	
	printf("Avg = %lf \nGeometric = %lf \n Harmonic = %lf",avg,geo,har);
	
	return 0;
}
