/*
4. Count numbers higher than the average of an array. 
*/
#include <stdio.h>
void main()
{
	int i,avg,n,a[100],sum=0,c=0;
	printf("Enter n element: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	avg=sum/n;
	for(i=0;i<n;i++) {
		if(a[i] > avg) {
			c++;
		}
	}
	printf("Count which is higher than the average of an array : %d",c);
}
