// Read n numbers from user and print in normal and reverse order.
#include <stdio.h>
void main()
{
	int n,a[256],i;
	printf("enter n [0-256]: ");
	scanf("%d",&n);
	printf("enter array : \n");
	
	for(i=0;i<n;i++)
	{
		scanf(" %d",&a[i]);
	}
	printf("printing array in normal order : \n");
	for(i=0;i<n;i++)
	{
		printf(" %d \n",a[i]);
	}
	printf("\n");
	printf("printing array in reverse order : \n");
	for(i=n-1;i>=0;i--)
	{
		printf(" %d \n",a[i]);
	}
	
}
