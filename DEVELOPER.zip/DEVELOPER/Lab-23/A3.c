/*
 3. Count number of even or odd number from an array of n numbers. 
*/
#include <stdio.h>
void main()
{
	int i,n,a[100],even=0,odd=0;
	printf("Enter n element: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++) {
		if(a[i] %2==0) {
			even++;
		}
		else {
			odd++;
		}
	}
	
	printf("Even: %d \nOdd: %d",even,odd);
}
