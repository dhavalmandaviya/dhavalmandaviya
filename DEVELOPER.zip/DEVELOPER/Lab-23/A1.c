/*
1. Read n numbers from user and print in normal and reverse order.
*/
#include <stdio.h>
void main()
{
	int i,n,a[100];
	printf("Enter n element: ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) {
		scanf("%d",&a[i]);
	}
	printf("Normal order array : \n");
	for(i=0;i<n;i++) {
		printf("%d \n",a[i]);
	}
	
	printf("Reverse order array : \n");
	for(i=n-1;i>=0;i--) {
		printf("%d \n",a[i]);
	}
}
