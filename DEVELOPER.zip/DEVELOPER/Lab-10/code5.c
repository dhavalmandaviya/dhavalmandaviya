#include<stdio.h>
int main(){
	int s,b;
	printf("Enter a salary and bonus percentage: \n");
	scanf("%d %d", &s, &b);
	int bonus = (s*b)/100;
	printf("Total salary = %d", s+bonus);
	return 0;
}
