#include<stdio.h>
int main(){
	int a,b,c,d,e;
	printf("Enter a five subject marks:\n");
	scanf("%d %d %d %d %d", &a,&b,&c,&d,&e);
	float res= (a+b+c+d+e)/5;
	printf("Percentage = %f", res);
return 0;
}
