#include<stdio.h>
int main(){
	float w,h;
	printf("Enter a weight and height: \n");
	scanf("%f %f", &w, &h);
	printf("BMI = %f", w/(h*h));
	return 0;
}
