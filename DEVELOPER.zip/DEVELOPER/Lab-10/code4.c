#include<stdio.h>
int main(){
	int u,r;
	printf("Enter a value of Unit and Rate:\n");
	scanf("%d %d", &u, &r);
	printf("Ammonut of Electicity Bill = %d", u*r);
	return 0;
}
