#include <stdio.h>
int main() {
	int w,h;
	printf("Enter a value of W and H\n");
	scanf("%d %d", &w, &h);
	printf("Value of rectangle perimeter = %d", 2*(w+h));
	return 0;
}
