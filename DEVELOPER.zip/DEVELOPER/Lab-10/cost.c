#include<stdio.h>
int main(){
	float tc,dp;
	printf("Enter a Total cost and Discount: \n");
	scanf("%f %f", &tc, &dp);
	float d = dp/100;
	float fc = tc-(tc*d);
	printf("Total final cost of product = %f", fc);
	return 0;
}
