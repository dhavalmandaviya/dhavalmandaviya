#include<stdio.h>
int main(){
	int sp,cp;
	printf("Enter a Selling price and Cost price: \n");
	scanf("%d %d", &sp,&cp);
	float profit = (sp-cp);
	float p= (profit/cp)*100;
	printf("Total Profit percentage = %f", p);
	return 0;
}
