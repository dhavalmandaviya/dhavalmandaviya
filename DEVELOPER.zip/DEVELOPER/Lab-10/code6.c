#include<stdio.h>
int main(){
	float d,m,f;
	printf("Enter Distance, milage and Fuel price : \n");
	scanf("%f %f %f", &d,&m,&f);
	float cost = ((d/m)*f);
	printf("Total cost of fuel = %f", cost);
	return 0;
}
